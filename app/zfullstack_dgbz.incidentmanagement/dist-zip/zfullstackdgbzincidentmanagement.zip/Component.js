sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("zfullstackdgbz.incidentmanagement.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map