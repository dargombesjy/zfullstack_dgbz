sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("zfullstackdgbz.incidentmanagement.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);